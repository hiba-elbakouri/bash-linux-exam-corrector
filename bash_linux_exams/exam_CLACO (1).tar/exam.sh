#!/bin/bash

# Lancer le serveur Flask
./api &

# Attendre 5 secondes pour que le serveur se lance
sleep 5

# Fonction pour récupérer les ventes d'une carte graphique
get_sales() {
    local gpu="$1"
    local sales=$(curl -s "http://172.31.6.136:5000/$gpu")
    echo "$gpu:$sales"
}

# Boucle pour récupérer les ventes toutes les minutes
while true; do
    date=$(date)
    echo "$date" >> sales.txt
    echo "$(get_sales rtx3060)" >> sales.txt
    echo "$(get_sales rtx3070)" >> sales.txt
    echo "$(get_sales rtx3080)" >> sales.txt
    echo "$(get_sales rtx3090)" >> sales.txt
    echo "$(get_sales rx6700)" >> sales.txt
    sleep 60
done
