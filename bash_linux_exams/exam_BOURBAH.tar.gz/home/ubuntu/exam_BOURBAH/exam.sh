#!bin/bash
function get_sales() {
    url_vente="http://0.0.0.0:5000/"
    cartes_graphique=("rtx3060 rtx3070 rtx3080 rtx3090 rx6700")
    for carte in $cartes_graphique
    do
        url_carte=$url_vente$carte
        #echo $url_carte
        nb_vente="$(curl $url_carte)"
        echo $carte ":" $nb_vente
    done
}
NOW=$(date +"%c")
echo $NOW >> sales.txt
get_sales >> sales.txt