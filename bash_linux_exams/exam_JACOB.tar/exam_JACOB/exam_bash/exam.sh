#!/usr/bin/bash

CARD_NAME="rtx3060 rtx3070 rtx3080 rtx3090 rx6700"
PORT=5000
FICHIER=~/exam_JACOB/exam_bash/sales.txt

echo $FICHIER
echo "$(date)">>$FICHIER
for card in $CARD_NAME; do
	  
	echo $card ":" $(curl "http://0.0.0.0:$PORT/$card") >> $FICHIER 
done
