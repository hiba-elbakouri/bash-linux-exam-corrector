#!/bin/bash

print_sales() {

path="/home/ubuntu/exam_Rim_Touhami/sales.txt"
arr=("$@")
d=`date`
echo $path
echo $d>>$path
for i in "${arr[@]}";
      do
        url="http://0.0.0.0:5000/"$i
        c=`curl $url`
        echo "$i:$c" >>$path
      done

}

array=(rtx3060 rtx3070 rtx3080 rtx3090 rx6700)
print_sales ${array[@]}
