#!/bin/bash
date >> ~/exam_ferreira_da_mata/sales.txt

for i in 'rtx3060' 'rtx3070' 'rtx3080' 'rtx3090' 'rx6700'
do
ventes=$(curl -s "http://0.0.0.0:5000/$i")
echo $i : $ventes >> ~/exam_ferreira_da_mata/sales.txt
done

