import pandas as pd
import random
from fastapi import FastAPI, Depends, HTTPException, Body, Query
from fastapi.security import HTTPBasic, HTTPBasicCredentials

df = pd.read_csv('questions.csv').fillna("")

app = FastAPI(title="API_QCM",
              description="API de Samuel Baheux, elle permet de générer des QCM aléatoirement selon le sujet de votre choix",
              openapi_tags=[
                  {
                      'name': 'Home',
                      'description': 'Outils API'
                  },
                  {
                      'name': 'get questions',
                      'description':
                          'Sort les questions en fonction du sujet choisi'
                  },
                  {
                      'name': 'generate questions',
                      'description': 'Permet de générer de nouvelles questions'
                  }
              ]
              )

security = HTTPBasic()

users = {
    "alice": "wonderland",
    "bob": "builder",
    "clementine": "mandarine",
    'admin': '4dm1N'
}


def authenticate_user(credentials: HTTPBasicCredentials = Depends(security)):
    """
    Verification des identifiants de l'utilisateur

    credentials : HTTPBasicCredentials
        Les identifiants de l'utilisateur depuis le header HTTP Basic
    """
    if credentials.username in users and users[credentials.username] == credentials.password:
        return credentials.username
    raise HTTPException(
        status_code=401,
        detail="Identifiant ou mot de passe incorrect",
    )


@app.get("/alive", tags=["check"])
def is_alive():
    """
    Verification du fonctionnement de l'API
    """
    try:
        if 'question' in df.columns:
            return {"message": "L'API fonctionne"}
        else:
            raise Exception("Données inaccessibles")
    except Exception as e:
        print(f"Erreur détectée: {e}")
        raise HTTPException(status_code=500, detail="L'API ne fonctionne pas")


@app.get("/questions", tags=["Obtenir questions"])
def get_questions(
        subject: str = Query(
            "Sujet",
            description="Sujet des questions",
        ),
        theme: str = Query(
            "Theme",
            description="Thème des questions",
        ),
        num_questions: int = Query(
            10,
            description="Nombre de questions ",
        ),
        username: str = Depends(authenticate_user),
) -> list:
    try:
        filtered = df[
            (df["subject"] == subject) &
            (df["use"] == theme)]
        if filtered.shape[0] < num_questions:
            raise HTTPException(status_code=400,
                                detail="Pas assez de questions disponibles")
        else:
            return random.sample(filtered.to_dict("records"),
                                 num_questions)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/add-questions", tags=["Create questions"])
def add_question(
        question_data: dict = Body({
            "question": "Quel language est considéré comme orienté objet?",
            "subject": "programmation",
            "use": "Language de programmation",
            "correct": "A",
            "responseA": "Java",
            "responseB": "R",
            "responseC": "linux",
            "responseD": "sas",
            "remark": "NaN"
        },
            description="Les données de la question"),
        username: str = Depends(authenticate_user)
) -> dict:
    if username != "admin":
        raise HTTPException(status_code=403,
                            detail="Accès refusé : il faut etre administrateur pour ajouter une question")
    new_question = pd.DataFrame([question_data])
    global df_quest
    df_quest = pd.concat([df, new_question], ignore_index=True)
    return {"Message": "La question a bien été ajoutée"}


