#!/bin/bash

echo "1. Énoncé de la question 1"  >> res_jq.txt
echo "Commande : cat people.json | jq '.[] | {name: .name, attributs: length}' | head -n 12"  >> res_jq.txt
echo "Réponse : réponse de la question 1 si demandé"  >> res_jq.txt
cat people.json | jq '.[] | {name: .name, attributs: length}' | head -n 48 >> res_jq.txt
echo -e "\n---------------------------------------------------------------------------------------------------\n" >> res_jq.txt

echo "2. Énoncé de la question 2"  >> res_jq.txt
cat people.json | jq 'group_by(.birth_year)[] | {birth_year: .[0].birth_year, attributs: length} | select(.birth_year=="unknown")'  >> res_jq.txt
echo "Commande : cat people.json | jq 'group_by(.birth_year)[] | {birth_year: .[0].birth_year, attributs: length} | select(.birth_year=="unknown")' "  >> res_jq.txt
echo "Réponse : réponse de la question 2 si demandé"  >> res_jq.txt
cat people.json | jq 'group_by(.birth_year)[] | {birth_year: .[0].birth_year, attributs: length} | select(.birth_year=="unknown")'  >> res_jq.txt
echo -e "\n---------------------------------------------------------------------------------------------------\n" >> res_jq.txt

echo "3. Énoncé de la question 3" >> res_jq.txt
echo "Commande :cat people.json | jq '.[] | {name: .name, created: (.created | split("T")[0])}' | head -n 10" >> res_jq.txt
echo "Réponse : réponse de la question 3 si demandé" >> res_jq.txt
cat people.json | jq '.[] | {name: .name, created: (.created | split("T")[0])}' | head -n 40  >> res_jq.txt
echo -e "\n---------------------------------------------------------------------------------------------------\n"  >> res_jq.txt


echo "4. Énoncé de la question 4"  >> res_jq.txt
echo "Commande : <commande pour répondre>"  >> res_jq.txt
echo "Réponse : réponse de la question 4 si demandé"  >> res_jq.txt
echo -e "\n---------------------------------------------------------------------------------------------------\n"  >> res_jq.txt


echo "5. Énoncé de la question 5"  >> res_jq.txt

echo "Commande : cat people.json | jq '.[] | {name: .name, film: .films[0]}' | head -n 40"  >> res_jq.txt
echo "Réponse : réponse de la question 5 si demandé"  >> res_jq.txt
cat people.json | jq '.[] | {name: .name, film: .films[0]}' | head -n 40  >> res_jq.txt
echo -e "\n---------------------------------------------------------------------------------------------------\n"  >> res_jq.txt



echo -e "\n----------------BONUS----------------\n" 

cp people.json bonus/people_6.json  

echo "6. Énoncé de la question 6"  

echo "Commande :  cat people_6.json | jq 'map(select(.height | test("^[0-9]+$")))' < people_6.json "  
echo "Réponse : réponse de la question 6 si demandé" 
cat people.json | jq 'map(select(.height | test("^[0-9]+$")))' > bonus/people_6.json 
echo -e "\n---------------------------------------------------------------------------------------------------\n"  



echo "7. Énoncé de la question 7"  

echo "Commande :  cat people_6.json | jq 'map(select(.height | test("^[0-9]+$"))) | .[] | .height |= tonumber' < people_7.json"  
echo "Réponse : réponse de la question 7 si demandé" 
cat bonus/people_6.json | jq 'map(if has("height") then .height |= tonumber else . end)' > bonus/people_7.json

echo -e "\n---------------------------------------------------------------------------------------------------\n"  

echo "8. Énoncé de la question 8"  

echo "Commande :  at bonus/people_7.json | jq 'map(select((.height | tonumber) >= 156 and (.height | tonumber) <= 171)
)' > people_8.json "  
echo "Réponse : réponse de la question 8 si demandé" 
cat bonus/people_7.json | jq 'map(select((.height | tonumber) >= 156 and (.height | tonumber) <= 171))' > bonus/people_8.json
echo -e "\n---------------------------------------------------------------------------------------------------\n"  


echo "9. Énoncé de la question 9"  

echo "Réponse : réponse de la question 9 si demandé" 
cat bonus/people_8.json | jq -r 'sort_by(.height | tonumber) | .[0] | "\(.name) is \(.height) tall"' > bonus/people_9.json
echo -e "\n---------------------------------------------------------------------------------------------------\n"  

