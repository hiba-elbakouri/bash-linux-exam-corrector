
#!/bin/bash
scrap_vente() {
	carte_graphique=$1
	ventes=$(curl "http://0.0.0.0:5000/$carte_graphique" 2>/dev/null)
        echo "$carte_graphique : $ventes" >> /home/ubuntu/exam_sall/exam_SALL/exam_bash/sales.txt
}
echo "$(date)" >> /home/ubuntu/exam_sall/exam_SALL/exam_bash/sales.txt
for carte_graphique in 'rtx3060' 'rtx3070' 'rtx3080' 'rtx3090' 'rx6700'
do 
	scrap_vente $carte_graphique
done
