#!/bin/bash
echo "1. Énoncé de la question 1"
cat people.json | jq '.[] | {name,count: length}' | head -12
echo "Nous pouvons constater qu'il y a 17 attributs par documents sur les documents afficher par head"
echo -e "\n---------------------------------\n"

echo "2.  Énoncé de la question 2"
cat people.json | jq 'group_by(.birth_year)[] | {test: .[0].birth_year, count: length}' | tail -4
echo "On peut constater qu'il y a 42 valeurs unknow pour l'attribut date d'anniversaire. Cela peut être du \n a un oublie ou a un champ mal renseigné"
echo -e "\n---------------------------------\n"

echo "3. Énoncé de la question 3"
cat people.json | jq '.[:10] | .[] | {name, created: .created[0:10]}'
echo -e "\n---------------------------------\n"

echo "5. Énoncé de la question 5"
cat people.json | jq '.[:10] | .[] | {films: .films[0][26:27], name: .name}'
echo "Si j'ai bien compris la question... Car je ne la trouve pas très claire"
echo "pour moi la question, c'est prendre le premier film de chaque de document et de récupérer son numéro et de l'associer \n au nom du personnage du document"
echo -e "\n---------------------------------\n"


echo "4. Énoncé de la question 4"
cat people.json | jq 'group_by(.birth_year)[] | {test: .[0].birth_year,count : length} '
echo "J'ai essayé de faire cette commande mais je n'ai pas réussi à la faire fonctionner :\n cat people.json | jq 'group_by(.birth_year)[] | {test: .[0].birth_year,count : length} |sort_by(.count)'"
echo "j'ai passé plusieus heures dessus je n'ai pas réussi à la faire si vous avez une idée.."
echo "Sinon, pour les dates de naissances similaires cela peut être du qu'ils soient jumeaux comme Leia et Luke, qu'ils soient \n tout simplement nés le même jour ou dû à une erreur de frappe"
echo -e "\n---------------------------------\n"
