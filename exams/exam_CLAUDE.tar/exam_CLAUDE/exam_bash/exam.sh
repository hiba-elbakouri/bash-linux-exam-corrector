#!/bin/bash
cartes=( rtx3060 rtx3070 rtx3080 rtx3090 rx6700)
echo "Données prises le $(date)" >>/home/ubuntu/exam_CLAUDE/exam_bash/sales.txt
function my_function() {
local htp=$1
shift
local arr=("$@")
for carte in "${arr[@]}";
do
http=""$htp$carte""
curl_out=$(curl "$http")
echo "le nombre de carte $carte est de $curl_out">>/home/ubuntu/exam_CLAUDE/exam_bash/sales.txt
done
}
my_function "http://0.0.0.0:5000/" "${cartes[@]}"

#Plus jamais de bash svp
