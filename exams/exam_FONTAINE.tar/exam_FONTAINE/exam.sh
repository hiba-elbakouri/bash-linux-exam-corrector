#!/bin/bash
# table des cartes graphiques
array_nom_carte=(rtx3060 rtx3070 rtx3080 rtx3090 rx6700)
#nom du fichier
nom_fichier=sales.txt
#chemin de destination
chemin=/home/ubuntu/exam_FONTAINE


#fonction de recupération des données et ecriture dans le fichier de sortie
function get_data {
resultat=$(curl http://172.31.39.240:5000/$1)
echo $1:$resultat >> $chemin/$nom_fichier
}

# date dans le fichier de sortie
date >> $chemin/$nom_fichier

#boucle sur les cartes et appel de la fonction de recupératon données et d'écriture dans un fichier
for nom_carte in "${array_nom_carte[@]}"
do
get_data $nom_carte

done

