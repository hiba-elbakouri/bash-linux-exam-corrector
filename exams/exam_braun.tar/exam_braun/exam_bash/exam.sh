#!/bin/bash
function gpu_sales {
	echo "$(date)" >> sales.txt
	for gpu in 'rtx3060' 'rtx3070' 'rtx3080' 'rtx3090' 'rx6700'
	do
		gpu_sale=$(curl -s "http://0.0.0.0:5000/$gpu")
		echo "$gpu: $gpu_sale" >> sales.txt
	done
}
gpu_sales
