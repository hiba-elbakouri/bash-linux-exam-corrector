#!/bin/bash

echo "1. Statment of question 1"
cat people.json | jq 'group_by(.eye_color)[] | {gender: .[0].eye_color, count: .|length}'
echo "cat people.json | jq 'group_by(.eye_color)[] | {gender: .[0].eye_color, count: .|length}'"
echo "Answer: 17"
echo -e "\n--------------------------------------\n"


echo "2. Statment of question 2"
cat people.json | jq 'group_by(.birth_year)[] | {birth_year: .[0].birth_year, count: .|length}'| tail -n 4
echo "cat people.json | jq 'group_by(.birth_year)[] | {birth_year: .[0].birth_year, count: .|length}'| tail -n 4"
echo "Answer: 42"
echo -e "\n--------------------------------------\n"

echo "3. Statment of question 3"
cat people.json | jq '.[] | .created[:10]+" "+.name'| head -n 10
echo "cat people.json | jq '.[] | .created[:10]+" "+.name'| head -n 10"
echo -e "\n--------------------------------------\n"

